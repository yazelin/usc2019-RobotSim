﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Server_test
{
	class ServerExmaple
	{
		private TcpListener myTcpListener;
		private TcpClient myClient;

		public ServerExmaple() { }

		internal void Start(string ip, int port)
		{
			if (myTcpListener != null)
			{
				return;
			}
			myTcpListener = new TcpListener(IPAddress.Parse(ip), port);
			myTcpListener.Start();
			Task.Run(() => ServerService());
		}

		private void ServerService()
		{
			while (true)
			{
				try
				{
					if (myTcpListener != null)
						myClient = myTcpListener.AcceptTcpClient();
						StreamReader streamReader = new StreamReader(myClient.GetStream());
						StreamWriter streamWriter = new StreamWriter(myClient.GetStream());

						while (myClient.Connected)
						{

							var data = streamReader.ReadLine();
							Console.WriteLine("From Client: " + data);

							streamWriter.WriteLine(data);
							streamWriter.Flush();
							Console.WriteLine("Server To Client: " + data);

							SpinWait.SpinUntil(() => { return false; }, 10);
						}

						myClient.Close();
				}
				catch (Exception ex)
				{
					Console.WriteLine(ex.ToString());
				}
				SpinWait.SpinUntil(() => { return false; }, 10);
			}
		}

		internal void Stop()
		{
			if (myTcpListener != null)
			{
				myTcpListener.Stop();
				myTcpListener.Server.Close();
				myTcpListener = null;
				myClient.Close();
			}
		}
	}
}
