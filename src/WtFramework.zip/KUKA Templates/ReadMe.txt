﻿The templates that were installed in this folder should not be modified as they will be removed on uninstall.
To keep a user defined templates, an other filename must be used.

To create a custom template you can rename one of the existing templates and modify its content.
The original template will still be displayed as it is also stored in a user independent directory.